<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Latihan 12 Javascript : Perulangan</title>
</head>
<body>
	<script type="text/javascript">
		// for(let i = 0; i < 10;i++){
		// 	document.write("<p>Perulangan ke-"+i+"</p>");
		// }

		// var languages = ["Javascript","HTML","CSS","Typescript"];

		// for(i=0;i<languages.length;i++){
		// 	document.write(i+". "+languages[i]+"<br/>");
		// }

		for(let i = 0; i < 10;i++){
			for(let j = 0; j < 10; j++){
				document.write("<p>Perulangan ke "+i+","+j+"</p>");
			}
		}
	</script>
</body>
</html>