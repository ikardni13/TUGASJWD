<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Latihan 1 : Internal CSS</title>
	<style type="text/css">
		body{
			background-color: lightblue;
		}

		/*h1{
			color : white;
			text-align: center;
		}*/

		p{
			font-family: verdana;
			font-size: 20px;
		}

		.myClass{
			font: bold 1.25em times;
			color: red;
		}
	</style>
</head>
<body>
	Selamat Datang di Contoh CSS 1

	<h1>Nama Saya Ika Ardianiningsih</h1>

	<p>Saya Ika dari POLINES </p>

	<h1 class="myClass">Ini adalah IKA</h1>
	<p class="myClass">Ini adalah Mahasiswa Polines</p>
</body>
</html>