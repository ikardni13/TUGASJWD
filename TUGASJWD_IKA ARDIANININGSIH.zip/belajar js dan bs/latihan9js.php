<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Latihan 9 : Javascript IF/ELSE</title>
</head>
<body>
	<script type="text/javascript">
		var password = prompt("Password:");

		if(password=="123IKA"){
			document.write("<h2>Selamat datang di website kami</h2>");
		}else{
			document.write("<h2>Password salah, coba lagi</h2>");
		}

		document.write("<p>Terima kasih sudah menggunakan aplikasi ini</p>");
	</script>
</body>
</html>