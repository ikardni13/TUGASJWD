<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laihan 8 : Javascript Kondisi IF</title>
</head>
<body>
	<script type="text/javascript">
		var totalBelanja = prompt("Total Belanja?",0);

		if(totalBelanja > 100000){
			document.write("<h2>Selamat Anda dapat hadiah</h2>");
		}

		document.write("<p>Terima kasih telah berbelanja di toko kami</p>");
	</script>
</body>
</html>