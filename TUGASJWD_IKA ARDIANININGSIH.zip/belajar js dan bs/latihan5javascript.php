<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Latihan 5 : Javascript</title>
	<script type="text/javascript">
		console.log("hello JS dari header")
	</script>
</head>
<body>
	<a href="#" onclick="alert('Yey')">Klik Saya</a>
</body>
</html>
<script src="js/filejavascript.js"></script>
<script type="text/javascript">
	console.log("Saya belajar Javascript");
	document.write("Hello world");
</script>