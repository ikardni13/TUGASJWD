<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Latihan 15 Ujicoba Aplikasi</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
	<div sty class="col-12" style="background-color: aquamarine;">
		Nama Saya Ika Ardianiningsih
	</div>
	<div class="col-6" style="background-color: blueviolet;">
		Dari Jurusan Akuntansi Politeknik Negeri Semarang
	</div>
</body>
<script src="js/bootstrap.min.js"></script>
</html>