<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Latihan 3 : Inline CSS</title>
</head>
<body>
	<h1 style="color:navy; text-align: center;">SELAMAT DATANG SEMUANYA</h1>
	<p style="color: red;">Selamat Mempelajari Inline CSS</p>
</body>
</html>