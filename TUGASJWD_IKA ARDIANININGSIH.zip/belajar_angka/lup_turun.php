<!DOCTYPE html>
<html>
<head>
    <title>Pola Angka</title>
</head>
<body>
    <?php
    for ($i = 10; $i >= 0; $i -= 2) {
        echo $i . "<br>";
    }
    ?>
</body>
</html>
