<!DOCTYPE html>
<html>
<head>
    <title>Pola Angka</title>
</head>
<body>
    <?php
    for ($i = 0; $i <= 9; $i++) {
        for ($j = 0; $j <= 9; $j++) {
            echo $i;
        }
        echo "<br>";
    }
    ?>
</body>
</html>
