<!DOCTYPE html>
<html lang="en">
<head>
<title>Percabangan Ternary</title>
</head>
<body>
<script>
var jwb = prompt("Apakah Jakarta ibu kota Indonesia?");
var jawaban = (jwb.toUpperCase() === "IYA") ? "Benar" : "Salah";
document.write(`Jawaban Anda: <b>${Jakarta}</b>`);
</script>
</body>
</html>
