<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Perulangan Text</title>
</head>
<body>
	<script type="text/javascript">
		for (var counter = 10; counter > 0; counter--) {
			document.write("<p>Perulangan ke " + counter + "</p>");
		}
</script>
</body>
</html>