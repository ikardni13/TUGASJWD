<!DOCTYPE html>
<html lang="en">
<head>
<title>Operator Penugasan</title>
</head>
<body>
<script>
document.write("Mula-mula nilai score...<br>");
// pengisian nilai
var score = 100;
document.write("score = " + score + "<br/>");

// pengisian dan menjumlahkan dengan 5
score += 5;
document.write("score = " + score + "<br/>");

// pengisian dan pengurangan dengan 2
score -= 2;
document.write("score = " + score + "<br/>");

// pengisian dan pembagian dengan 4
score /= 4;
document.write("score = " + score + "<br/>");

// pengisian dan pemangkatan dengan 2
score **= 2;
document.write("score = " + score + "<br/>");

// pengisian dan modulo dengan 3
score %= 3;
document.write("score = " + score + "<br/>");
</script>
</body>
</html>
