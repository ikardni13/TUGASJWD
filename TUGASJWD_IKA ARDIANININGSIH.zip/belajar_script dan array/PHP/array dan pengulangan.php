<!DOCTYPE html>
<html lang="en">
<head>
  <title>Array dan perulangan</title>
</head>
<body>
  <script>
    // membuat array
    var products = ["Senter", "Radio", "Antena", "Obeng"];
    document.write("<h3>Daftar Produk:</h3>");
    document.write("<ol>");
    
    // menggunakan perulangan untuk mencetak semua isi array
    products.forEach((data) => {
      document.write(`<li>${data}</li>`);
    });
    
    document.write("</ol>");
  </script>
</body>
</html>
