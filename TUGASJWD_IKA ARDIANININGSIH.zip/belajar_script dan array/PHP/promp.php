<!DOCTYPE html>
<html>
<head>
<title>Dialog Promp</title>
</head>
<body>
<script>
var nama = prompt("Siapa nama kamu?", ""); document.write("<p>Hello "+ nama +"</p>");
</script>
</body>
</html>