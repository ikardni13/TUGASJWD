<!DOCTYPE html>
<html>
<head>
<title>Dialog Confirm</title>
</head>
<body>
<script>
var yakin = confirm("Apakah kamu yakin akan mengunjungi petanikode?")

if (yakin) {
window.location = "https://www.petanikode.com";
} else {
document.write("Baiklah, tetap di sini saja ya :)");
}
</script>
</body>
</html>