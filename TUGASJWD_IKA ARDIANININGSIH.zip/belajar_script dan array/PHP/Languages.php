<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Languages</title>
</head>
<body>
	<script type="text/javascript">
		var languages = ["Javascript", "HTML", "CSS", "Typescript"];
		for (var i = 0; i < languages.length; i++) {
			document.write(i + ". " + languages[i] + "<br/>");
		}
	</script>
</body>
</html>
