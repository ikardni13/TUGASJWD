<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Hello World</title>
</head>
<body>
	<div id="output"></div>

	<script type="text/javascript">
		var namaFungsi = () => {
			var outputDiv = document.getElementById("output");
			outputDiv.innerHTML = "Hello World!";
		};

		namaFungsi();
	</script>
</body>
</html>
